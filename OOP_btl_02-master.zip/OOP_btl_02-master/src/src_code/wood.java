/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package src_code;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

/**
 *
 * @author h
 */
public class wood extends JLabel  {
    int x, y;
    private static ImageIcon hinhWood = new ImageIcon("image\\wood.png");
    public wood(int x_, int y_) {
        this.setIcon(hinhWood);
        this.x = x_;
        this.y = y_;
        this.setBounds(x, y, 64, 64);
    }
    
}

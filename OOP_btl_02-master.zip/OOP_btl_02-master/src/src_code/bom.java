/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package src_code;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

/**
 *
 * @author h
 */
public class bom extends JLabel{
    int x, y;
    private static int a[] = {-1, 1, 0, 0, 0};
    private static int b[] = {0, 0, -1, 1, 0};
private static ImageIcon quaBom = new ImageIcon("image\\bom.png"), bomNo = new ImageIcon("image\\no1.png");
    int timeKichNo = 2000, timeNo = 500;
    public bom(int x_, int y_) {
        if((x_%display.size) < 40)
            this.x = (x_/display.size)*display.size;
        else
            this.x = (x_/display.size+1)*display.size; 
        if((y_%display.size) < 40)
            this.y = (y_/display.size)*display.size;
        else
            this.y = (y_/display.size+1)*display.size;
        display.nenn[y/display.size][x/display.size].setIcon(quaBom);
        this.setBounds(x, y, display.size, display.size);
    }
    public void noBom(){
        if(timeKichNo != 0){
            timeKichNo -= 100;
        }
        else{
            if(timeNo == 500){
                display.nenn[y/display.size][x/display.size].setIcon(bomNo);
                for(int i = 0;i < a.length;i ++){
                    for(int j = 0;j < display.listWood.size();j ++){
                        if(display.listWood.elementAt(j).y == (y/display.size + a[i])*display.size
                            && display.listWood.elementAt(j).x == (x/display.size + b[i])*display.size){
                           display.listWood.elementAt(j).setVisible(false);
                           display.listWood.remove(j);
                        }
                    }
                }
                display.nenn[y/display.size - 1][x/display.size].setIcon(bomNo);
                display.nenn[y/display.size + 1][x/display.size].setIcon(bomNo);
                display.nenn[y/display.size][x/display.size - 1].setIcon(bomNo);
                display.nenn[y/display.size][x/display.size + 1].setIcon(bomNo);
            }
            kill();
            timeNo -= 100;
            if(timeNo != 0)
                return;
            display.nenn[y/display.size][x/display.size].setIcon(nen.hinhNen);
            display.nenn[y/display.size - 1][x/display.size].setIcon(nen.hinhNen);
            display.nenn[y/display.size + 1][x/display.size].setIcon(nen.hinhNen);
            display.nenn[y/display.size][x/display.size - 1].setIcon(nen.hinhNen);
            display.nenn[y/display.size][x/display.size + 1].setIcon(nen.hinhNen);
            display.jp.remove(this);
            for(int i = 0;i < display.listBom.size();i ++)
                if(display.listBom.elementAt(i) == this){
                    display.listBom.remove(i);
                    break;
                }
        }
    }
    public void kill() {
        for(int i = 0;i < a.length;i ++){
            for(int j = 0;j < display.listGhost.size();j ++){
                int tmpx = display.listGhost.elementAt(j).x;
                int tmpy = display.listGhost.elementAt(j).y;
                if(tmpx%display.size >= 40) tmpx = ((tmpx/display.size) + 1)*display.size;
                    else tmpx = (tmpx/display.size)*display.size;
                if(tmpy%display.size >= 40) tmpy = ((tmpy/display.size) + 1)*display.size;
                else tmpy = (tmpy/display.size)*display.size;
                if(tmpx == (x/display.size + a[i])*display.size
                    &&    tmpy == (y/display.size + b[i])*display.size){
                    display.listGhost.elementAt(j).setVisible(false);
                    display.listGhost.remove(j);
                }
            }
            int tmpx = display.bomber_man.x;
            int tmpy = display.bomber_man.y;
            if(tmpx%display.size >= 40) tmpx = ((tmpx/display.size) + 1)*display.size;
                else tmpx = (tmpx/display.size)*display.size;
            if(tmpy%display.size >= 40) tmpy = ((tmpy/display.size) + 1)*display.size;
            else tmpy = (tmpy/display.size)*display.size;
            if(tmpx == (x/display.size + a[i])*display.size
                &&    tmpy == (y/display.size + b[i])*display.size){
                display.bomber_man.setIcon(new ImageIcon("image//thayma.png"));
                
                display.bomber_man.dead = true;
                
                
                
            
            }
        }
    }
}
